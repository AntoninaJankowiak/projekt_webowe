
file = open("slowa.txt", "r")
file1 = open("wyniki4_1.txt", "w")
file2 = open("wyniki4_2.txt", "w")
file3 = open("wyniki4_3.txt", "w")
for line in file:
    wCount = line.count('w')
    aCount = line.count('a')
    kCount = line.count('k')
    cCount = line.count('c')
    jCount = line.count('j')
    eCount = line.count('e')
    wakacjeCount = 0
    if wCount == kCount:
        file1.write(line)
    #4.3 czesciowo najpierw bo zmieniam te zmienne count potem
    #if not (wCount > 0 and aCount > 1 and kCount > 0 and cCount > 0 and jCount > 0 and eCount > 0):
        #wakacje = len(line)
        #file3.write(str(wakacje)+' ')
        #completed = True
    #else:
        #completed = False

    while wCount > 0 and aCount > 1 and kCount > 0 and cCount > 0 and jCount > 0 and eCount > 0:
        wakacjeCount = wakacjeCount + 1
        wCount = wCount - 1
        aCount = aCount - 2
        kCount = kCount - 1
        cCount = cCount - 1
        jCount = jCount - 1
        eCount = eCount - 1

    file2.write(str(wakacjeCount)+' ')

    notdelete = 0
    for i in range(0, len(line.strip())-6, 1):
        if line[i] != 'w':
            continue
        elif line[i+1] != 'a':
            continue
        elif line[i+2] != 'k':
            continue
        elif line[i+3] != 'a':
            continue
        elif line[i+4] != 'c':
            continue
        elif line[i+5] != 'j':
            continue
        elif line[i+6] != 'e':
            continue
        else:
            notdelete = notdelete + 7

    wakacje = len(line.strip()) - notdelete
    wakacje2 = len(line.strip()) - 7 * wakacjeCount
    print(line, len(line.strip()), notdelete, wakacje, wakacje2, wakacjeCount)
    file3.write(str(wakacje) + ' ')


